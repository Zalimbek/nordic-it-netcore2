﻿namespace HomeWorkDemo
{
	public enum LogRecordType
	{
		Info,
		Warning,
		Error
	}
}
