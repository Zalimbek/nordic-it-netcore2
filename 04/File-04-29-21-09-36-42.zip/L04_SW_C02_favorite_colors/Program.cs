﻿using System;

class Program
{
	[Flags]
	enum MyColors
	{
		// None = 0,
		Black = 0x1,
		Blue = 0x1 << 1,
		Cyan = 0x1 << 2,
		Grey = 0x1 << 3,
		Green = 0x1 << 4,
		Magenta = 0x1 << 5,
		Red = 0x1 << 6,
		White = 0x1 << 7,
		Yellow = 0x1 << 8,
	}

	static void Main(string[] args)
	{
		// рассчитываем переменную со всеми возможными цветами
		MyColors allColors = 0;
		foreach (MyColors color in Enum.GetValues(typeof(MyColors)))
		{
			allColors |= color;
		}

		// выводим возможные цвета за исключением "нулевого"
		Console.WriteLine("Список возможных цветов:");
		Console.WriteLine(allColors);

		// здесь будем хранить любимые цвета
		MyColors favoriteColors = 0;

		// прочитаем их
		for (int i = 0; i < 4; i++)
		{
			Console.Write($"Введите любимый цвет {i + 1}: ");

			object color = Enum.Parse(typeof(MyColors), Console.ReadLine());
			favoriteColors |= (MyColors)color;
		}

		// выводим любимые цвета
		Console.WriteLine("Любимые цвета:");
		Console.WriteLine(favoriteColors);
		Console.WriteLine();

		// рассчитываем нелюбимые цвета черех allColors XOR favoriteColors.
		MyColors notFavoriteColors = allColors ^ favoriteColors;

		// можно также инвертировать favoriteColors,
		// а потом "просеять" через AND с allColors.
		//MyColors notFavoriteColors = ~favoriteColors;
		//notFavoriteColors = (MyColors)(((int)notFavoriteColors << 23) >> 23 );

		Console.WriteLine("Нелюбимые цвета:");
		Console.WriteLine(notFavoriteColors);
		Console.WriteLine();

		Console.WriteLine("\nОтладочная информация:");
		WriteInt32ValueWithBits(allColors, nameof(allColors));
		WriteInt32ValueWithBits(favoriteColors, nameof(favoriteColors));
		WriteInt32ValueWithBits(notFavoriteColors, nameof(notFavoriteColors));
	}

	static void WriteInt32ValueWithBits(object value, string description)
	{
		Console.WriteLine(
			"Flags: {0} : {1}",
			Convert.ToString((int)value, 2).PadLeft(32, '0'),
			description);
	}
}
