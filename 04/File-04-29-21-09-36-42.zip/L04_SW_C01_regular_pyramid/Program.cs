﻿using System;

namespace L04_SW_C01_regular_pyramid
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine(
				"Расчёт параметров правильной пирамиды\n" +
				"-------------------------------------\n");

			Console.Write("Введите количество сторон в основании (целое): ");
			int n = int.Parse(Console.ReadLine());

			Console.Write("Введите величину стороны основания (дробное): ");
			double a = double.Parse(Console.ReadLine());

			Console.Write("Введите величину высоты пирамиды (дробное): ");
			double h = double.Parse(Console.ReadLine());

			double squareFull = n * a * (a / (2 * Math.Tan(Math.PI / n))
				+ Math.Sqrt(Math.Pow(h, 2) + Math.Pow(a / (2 * Math.Tan(Math.PI / n)), 2))) / 2;

			double squareSide = Math.Sqrt(Math.Pow(h, 2) + Math.Pow(a / (2 * Math.Tan(Math.PI / n)), 2))
				* n * a / 2;

			double value = h * n * Math.Pow(a, 2) / (12 * Math.Tan(Math.PI / n));

			Console.WriteLine($"Площадь полной поверхности: {squareFull:#.###}");
			Console.WriteLine($"Площадь боковой поверхности: {squareSide:#.###}");
			Console.WriteLine($"Объём: {value:#.###}");
		}
	}
}
