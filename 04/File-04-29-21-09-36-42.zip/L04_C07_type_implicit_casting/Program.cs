using System;

class Program
{
	static void Main()
	{
		int a = 10;
		double b = a;
		Console.WriteLine(b);

		double g = 9.8;
		// int c = g; // compiler gives an error for this line!
		Console.WriteLine(g);
	}
}