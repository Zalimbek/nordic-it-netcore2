using System;

class Program
{
	static void Main()
	{
		int number = 12;
		Console.WriteLine(number.ToString());	// 12

		bool boolean = true;
		Console.WriteLine(boolean.ToString());	// True

		DateTime now = DateTime.Now;
		Console.WriteLine(now.ToString());		// 1/1/2019 2:15:00 PM

		object me = new object();
		Console.WriteLine(me.ToString());		// System.Object

		string str = "abc";
		Console.WriteLine(str.ToString());		// abc :)
	}
}